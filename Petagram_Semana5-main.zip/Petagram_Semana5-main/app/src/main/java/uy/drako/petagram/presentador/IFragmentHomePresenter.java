package uy.drako.petagram.presentador;

public interface IFragmentHomePresenter {

    public void obtenerMascotasBaseDatos();

    public void mostrarMascotasRV();
}
